chrome.devtools.panels.elements.createSidebarPane(
    "Locator",
    function (sidebar) {
        sidebar.setPage('/popup.html');
    }
);